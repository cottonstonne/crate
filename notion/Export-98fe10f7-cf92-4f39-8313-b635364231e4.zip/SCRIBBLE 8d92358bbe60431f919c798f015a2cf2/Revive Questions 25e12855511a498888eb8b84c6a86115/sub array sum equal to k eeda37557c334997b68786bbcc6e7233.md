# sub array sum equal to k

Number: 560
Tags: hashmap, prefix sum
URL: https://leetcode.com/problems/subarray-sum-equals-k/
level: medium
video: https://www.youtube.com/watch?v=XjP2mQr98WQ&t=921s