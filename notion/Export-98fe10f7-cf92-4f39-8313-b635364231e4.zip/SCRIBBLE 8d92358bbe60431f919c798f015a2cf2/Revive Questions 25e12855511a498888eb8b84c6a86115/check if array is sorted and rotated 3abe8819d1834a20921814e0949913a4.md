# check if array is sorted and rotated

Number: 1752
Tags: array
URL: https://leetcode.com/problems/check-if-array-is-sorted-and-rotated/
level: easy
video: https://www.youtube.com/watch?v=t1GLDWqWVQk