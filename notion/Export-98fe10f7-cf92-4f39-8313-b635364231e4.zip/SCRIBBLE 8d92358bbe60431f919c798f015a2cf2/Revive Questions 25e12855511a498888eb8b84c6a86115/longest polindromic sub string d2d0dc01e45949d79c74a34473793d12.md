# longest polindromic sub string

Number: 5
Tags: <dp>, array
URL: https://leetcode.com/problems/longest-palindromic-substring/
level: medium
video: https://www.youtube.com/watch?v=ZJUGtWObroc&t=645s